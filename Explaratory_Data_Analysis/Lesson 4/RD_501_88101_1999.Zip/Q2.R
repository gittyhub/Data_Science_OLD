#2
#Have total emissions from PM2.5 decreased in the Baltimore City, Maryland (fips == "24510") 
#from 1999 to 2008? Use the base plotting system to make a plot answering this question.

#Checks to see if these files exists, else create them
if(!exists("NEI"))
  {
    NEI <- readRDS("summarySCC_PM25.rds")
  }
if(!exists("SCC"))
  {
    SCC <- readRDS("Source_Classification_Code.rds")
  }

#We know emission is on the NEI file
#From the NEI file, look for "fips" where it equals "24510", which is the code for Baltimore
#create a png
png("plot2.png")

Baltimorefips <- subset(NEI, fips == "24510")
BaltimoresumD <- tapply(Baltimorefips$Emissions, Baltimorefips$year, sum)
plot(names(BaltimoresumD), BaltimoresumD, type="l", xlab = "Year", ylab = "Baltimore total PM2.5 (tons)", main = "Baltimore PM2.5 Levels from 1999 to 2008")
dev.off()